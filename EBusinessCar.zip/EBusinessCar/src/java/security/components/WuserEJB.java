package security.components;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class WuserEJB {

    @PersistenceContext
    private EntityManager em;

    public void createWuser(Wuser user) {
        em.persist(user);
    }

    public Wuser findByUsername(String username) {
        TypedQuery<Wuser> query = em.createNamedQuery("Wuser.findByUsername", Wuser.class);
        query.setParameter("username", username);
        List<Wuser> results = query.getResultList();
        return results.isEmpty() ? null : results.get(0);
    }

    public Wuser findByEmail(String email) {
        TypedQuery<Wuser> query = em.createNamedQuery("Wuser.findByEmail", Wuser.class);
        query.setParameter("email", email);
        List<Wuser> results = query.getResultList();
        return results.isEmpty() ? null : results.get(0);
    }
    
    public void update(Wuser user) {
    // Logic to update the user in the database
        em.merge(user);
    }
}

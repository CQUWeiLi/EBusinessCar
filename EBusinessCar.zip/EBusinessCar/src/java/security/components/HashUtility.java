package security.components;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class HashUtility {

    private static final String HASH_ALGORITHM = "SHA-512";

    /**
     * Hashes a password using SHA-512.
     * 
     * @param password The plain text password to hash.
     * @return The hashed password as a Base64-encoded string.
     * @throws NoSuchAlgorithmException If the SHA-512 algorithm is not available.
     */
    public static String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance(HASH_ALGORITHM);
        byte[] hashedBytes = messageDigest.digest(password.getBytes());
        return Base64.getEncoder().encodeToString(hashedBytes);
    }

    /**
     * Validates a plain text password against a hashed password.
     * 
     * @param plainPassword The plain text password to validate.
     * @param hashedPassword The previously hashed password to compare against.
     * @return True if the plain password matches the hashed password, false otherwise.
     * @throws NoSuchAlgorithmException If the SHA-512 algorithm is not available.
     */
    public static boolean validatePassword(String plainPassword, String hashedPassword) throws NoSuchAlgorithmException {
        // Hash the plain password
        String hashedInput = hashPassword(plainPassword);

        // Compare the hashed input with the stored hashed password
        return hashedInput.equals(hashedPassword);
    }
}

package security.components;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

public class EmailUtility {

    private static final String SMTP_HOST = "localhost";
    private static final int SMTP_PORT = 2525;

    /**
     * Sends an email using the SMTP server.
     *
     * @param toEmail Recipient's email address
     * @param subject Subject of the email
     * @param messageBody Body of the email
     * @throws MessagingException if there is an error during sending the email
     */
    public static void sendEmail(String toEmail, String subject, String messageBody) throws MessagingException {
        // Set SMTP properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", SMTP_HOST);
        properties.put("mail.smtp.port", SMTP_PORT);

        // Create a session without authentication
        Session session = Session.getInstance(properties);

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("no-reply@yourdomain.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setText(messageBody);

            // Send the email
            Transport.send(message);
        } catch (MessagingException e) {
            throw new MessagingException("Error sending email: " + e.getMessage(), e);
        }
    }
}


package security.components;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.Flash;
import jakarta.inject.Inject;
import jakarta.mail.MessagingException;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named
@SessionScoped
public class RegisterBean implements Serializable {

    private String email;
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String inputVerificationCode;
    private String storedVerificationCode;
    
    private String inputRecoveryCode;
    private String storedRecoveryCode;
    private String newPassword;
    private Wuser user;
    
    @Inject
    private WuserEJB wuserEJB;

    // Getter and Setter methods
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getInputVerificationCode() {
        return inputVerificationCode;
    }

    public void setInputVerificationCode(String inputVerificationCode) {
        this.inputVerificationCode = inputVerificationCode;
    }

    public String getStoredVerificationCode() {
        return storedVerificationCode;
    }

    public void setStoredVerificationCode(String storedVerificationCode) {
        this.storedVerificationCode = storedVerificationCode;
    }

    public Wuser getUser() {
        return user;
    }

    public void setUser(Wuser user) {
        this.user = user;
    }

    public String getInputRecoveryCode() {
        return inputRecoveryCode;
    }

    public void setInputRecoveryCode(String inputRecoveryCode) {
        this.inputRecoveryCode = inputRecoveryCode;
    }

    public String getStoredRecoveryCode() {
        return storedRecoveryCode;
    }

    public void setStoredRecoveryCode(String storedRecoveryCode) {
        this.storedRecoveryCode = storedRecoveryCode;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
    
    

    // Method to complete registration if the verification code is correct
    public String completeRegistration() {
        //Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
        //this.email = (String) flash.get("email");
        //this.storedVerificationCode=(String) flash.get("verificationCode");
        if (this.inputVerificationCode.equals(this.storedVerificationCode)) {
            // Hash the password before saving
            String hashedPassword = null;
            try {
                hashedPassword = HashUtility.hashPassword(this.password);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(RegisterBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            // Save the user data to the Wuser entity
            Wuser newUser = new Wuser();
            newUser.setEmail(this.email);
            newUser.setFirstName(this.firstName);
            newUser.setLastName(this.lastName);
            newUser.setUsername(this.username);
            newUser.setPasswordHash(hashedPassword);

           
            wuserEJB.createWuser(newUser);  // Assuming WuserEJB has a create method

            return "Login.xhtml?faces-redirect=true";  // Redirect to Login page
        } else {
            // Handle the case when the verification code is incorrect
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Incorrect verification code: "+this.inputVerificationCode+" "+this.storedVerificationCode+" "+this.email, "Please enter the correct verification code."));
            Logger.getLogger(RegisterBean.class.getName()).log(Level.INFO, null, this.inputVerificationCode);
            Logger.getLogger(RegisterBean.class.getName()).log(Level.INFO, null, this.storedVerificationCode);
            return null;
        }
    }
        public String generateVerificationCode(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
        Random random = new Random();
        StringBuilder code = new StringBuilder();

        for (int i = 0; i < length; i++) {
            code.append(characters.charAt(random.nextInt(characters.length())));
        }
        return code.toString();
    }

    // Method to send the verification code to the provided email address
    public void sendVerificationCode(String email) {
        // Generate a verification code of length 20
        this.storedVerificationCode = generateVerificationCode(20);
        //FacesContext.getCurrentInstance().getExternalContext().getFlash().put("verificationCode", verificationCode);

        // Send email with verification code
        try {
            EmailUtility.sendEmail(email, "Verification Code", 
                "Your verification code is: " + this.storedVerificationCode);
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage("Verification code sent successfully to " + email));
        } catch (MessagingException e) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Error sending verification code", e.getMessage()));
        }
    }

    // Method to be called when the email is submitted in the UI
    public String verifyEmailAndRedirect() {
        if (this.email != null && !this.email.isEmpty()) {
            // Store the email in Flash scope for the next page (Register.xhtml)
            //FacesContext.getCurrentInstance().getExternalContext().getFlash().put("email", this.email);
            //FacesContext.getCurrentInstance().getExternalContext().getFlash().put("verificationCode", verificationCode);
            
            // Send verification code to the user's email
            sendVerificationCode(this.email);
            return "Register.xhtml?faces-redirect=true";  // Redirect to Register.xhtml
        } else {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Email is required", "Please provide a valid email address"));
            return null;
        }
    }
    
    public String sendRecoveryCodeAndRedirect() {
        try {
            // Retrieve the user based on the entered email
            user = wuserEJB.findByEmail(email);

            if (user == null) {
                // If no user found with the provided email
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "No user found with this email.", null));
                return null;
            }

            // Generate a recovery code
            storedRecoveryCode = generateVerificationCode(20);

            // Send the recovery code via email (simulate email sending here)
            EmailUtility.sendEmail(email, "Recovery Code", 
                "Your recovery code is: " + this.storedRecoveryCode);

            // Add a success message
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, 
                                     "A recovery code has been sent to your email.", null));

            // Redirect to the recovery page
            return "PasswordRecovery.xhtml?faces-redirect=true";

        } catch (MessagingException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "An error occurred while processing your request.", null));
            return null;
        }
    }
    
    public String recover() {
        try {
            // Validate recovery code
            if (!storedRecoveryCode.equals(inputRecoveryCode)) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid recovery code.", null));
                return null;
            }

            // Hash the new password
            String hashedPassword = HashUtility.hashPassword(newPassword);

            // Update user's password in the database
            user.setPasswordHash(hashedPassword);
            wuserEJB.update(user);

            // Add a success message
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Password updated successfully!", null));

            // Redirect to the login page
            return "Login.xhtml?faces-redirect=true";

        } catch (NoSuchAlgorithmException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "An error occurred during recovery.", null));
            return null;
        }
    }

}

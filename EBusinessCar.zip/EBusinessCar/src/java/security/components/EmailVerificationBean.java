

package security.components;

import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import jakarta.faces.application.FacesMessage;
import jakarta.inject.Inject;
import jakarta.mail.MessagingException;
import java.io.Serializable;
import java.util.Random;

@Named
@RequestScoped
public class EmailVerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String email;
    private String verificationCode;

    // Getter and Setter methods for email and verificationCode
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    // Method to generate a random verification code of the specified length
    public String generateVerificationCode(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
        Random random = new Random();
        StringBuilder code = new StringBuilder();

        for (int i = 0; i < length; i++) {
            code.append(characters.charAt(random.nextInt(characters.length())));
        }
        return code.toString();
    }

    // Method to send the verification code to the provided email address
    public void sendVerificationCode(String email) {
        // Generate a verification code of length 20
        this.verificationCode = generateVerificationCode(20);
        FacesContext.getCurrentInstance().getExternalContext().getFlash().put("verificationCode", verificationCode);

        // Send email with verification code
        try {
            EmailUtility.sendEmail(email, "Verification Code", 
                "Your verification code is: " + this.verificationCode);
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage("Verification code sent successfully to " + email));
        } catch (MessagingException e) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Error sending verification code", e.getMessage()));
        }
    }

    // Method to be called when the email is submitted in the UI
    public String verifyEmailAndRedirect() {
        if (this.email != null && !this.email.isEmpty()) {
            // Store the email in Flash scope for the next page (Register.xhtml)
            FacesContext.getCurrentInstance().getExternalContext().getFlash().put("email", this.email);
            //FacesContext.getCurrentInstance().getExternalContext().getFlash().put("verificationCode", verificationCode);
            
            // Send verification code to the user's email
            sendVerificationCode(this.email);
            return "Register.xhtml?faces-redirect=true";  // Redirect to Register.xhtml
        } else {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Email is required", "Please provide a valid email address"));
            return null;
        }
    }
}

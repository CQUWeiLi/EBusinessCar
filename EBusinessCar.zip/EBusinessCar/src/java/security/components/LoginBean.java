package security.components;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named
@SessionScoped
public class LoginBean implements Serializable {

    @EJB
    private WuserEJB wuserEJB;

    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String login() {
        Wuser user = wuserEJB.findByUsername(username);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "user "+user, "user"));
        Logger.getLogger(LoginBean.class.getName()).log(Level.INFO, "user: {0}", user.toString());
        if (user == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid username "+this.username, null));
            return null;
        }
        try {
            Logger.getLogger(LoginBean.class.getName()).log(Level.INFO, "password {0}", HashUtility.hashPassword(this.password));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(LoginBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        Logger.getLogger(LoginBean.class.getName()).log(Level.INFO, "saved password {0}",user.getPasswordHash());
        try {
            
            // Validate the hashed password
            if (!HashUtility.validatePassword(password, user.getPasswordHash())) {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid password "+HashUtility.hashPassword(this.password)+" "+user.getPasswordHash(), null));
                return null;
            }
            Logger.getLogger(LoginBean.class.getName()).log(Level.INFO, "Login sucessful");
            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("loggedInUser", user);

            // Redirect to MainPage.xhtml
            return "/protected/MainPage.xhtml?faces-redirect=true";

        } catch (NoSuchAlgorithmException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "An error occurred during login.", null));
            return null;
        }
    }

    public String logout() {
        // Invalidate the session
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();

        // Redirect to the login page
        return "/Login.xhtml?faces-redirect=true";
    }
}

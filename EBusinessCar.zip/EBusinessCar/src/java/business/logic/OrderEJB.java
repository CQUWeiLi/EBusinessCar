package business.logic;

import business.entities.CarOrder;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class OrderEJB {

    @PersistenceContext(unitName = "CarPU")
    private EntityManager em;

    // Method to persist a new CarOrder
    public CarOrder createOrder(CarOrder order) {
        em.persist(order);
        return order;
    }

    // Method to query all Orders
    public List<CarOrder> findAllOrders() {
        TypedQuery<CarOrder> query = em.createNamedQuery("CarOrder.findAll", CarOrder.class);
        return query.getResultList();
    }

    // Method to query an CarOrder by ID
    public CarOrder findOrderById(Long id) {
        return em.find(CarOrder.class, id);
    }

    // Method to delete an CarOrder by ID
    public void deleteOrderById(Long id) {
        CarOrder order = findOrderById(id);
        if (order != null) {
            em.remove(order);
        } else {
            throw new IllegalArgumentException("Order not found for ID: " + id);
        }
    }

    // Method to update an CarOrder
    public CarOrder updateOrder(CarOrder order) {
        return em.merge(order);
    }
    
    public void deleteOrder(CarOrder order) {
    CarOrder managedOrder = em.find(CarOrder.class, order.getId());
    if (managedOrder != null) {
        em.remove(managedOrder);
    }
}
}

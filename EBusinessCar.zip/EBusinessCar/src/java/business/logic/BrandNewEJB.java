package business.logic;

import business.entities.BrandNewCar;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class BrandNewEJB {

    @PersistenceContext(unitName = "CarPU")
    private EntityManager em;

    // Method to persist a new BrandNewCar
    public BrandNewCar createBrandNewCar(BrandNewCar brandNewCar) {
        em.persist(brandNewCar);
        return brandNewCar;
    }

    // Method to query all BrandNewCars
    public List<BrandNewCar> findAllBrandNewCars() {
        TypedQuery<BrandNewCar> query = em.createNamedQuery("BrandNewCar.findAll", BrandNewCar.class);
        return query.getResultList();
    }

    // Method to query a BrandNewCar by reference number
    public BrandNewCar findByReferenceNumber(String referenceNumber) {
        TypedQuery<BrandNewCar> query = em.createNamedQuery("BrandNewCar.findByReferenceNumber", BrandNewCar.class);
        query.setParameter("referenceNumber", referenceNumber);
        return query.getSingleResult();
    }

    // Method to increase the number of cars in stock
    public void increaseCarNumber(String referenceNumber, int amount) {
        BrandNewCar car = findByReferenceNumber(referenceNumber);
        if (car != null) {
            car.setNumberOfCars(car.getNumberOfCars() + amount);
            em.merge(car); // update the entity
        }
    }

    // Method to reduce the number of cars in stock
    public void reduceCarNumber(String referenceNumber, int amount) {
        BrandNewCar car = findByReferenceNumber(referenceNumber);
        if (car != null && car.getNumberOfCars() >= amount) {
            car.setNumberOfCars(car.getNumberOfCars() - amount);
            em.merge(car); // update the entity
        } else {
            throw new IllegalArgumentException("Insufficient stock to reduce");
        }
    }
}


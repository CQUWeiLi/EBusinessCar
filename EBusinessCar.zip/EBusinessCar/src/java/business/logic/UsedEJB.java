package business.logic;

import business.entities.UsedCar;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class UsedEJB {

    @PersistenceContext(unitName = "CarPU")
    private EntityManager em;

    // Method to persist a new UsedCar
    public UsedCar createUsedCar(UsedCar usedCar) {
        em.persist(usedCar);
        return usedCar;
    }

    // Method to query all UsedCars
    public List<UsedCar> findAllUsedCars() {
        TypedQuery<UsedCar> query = em.createNamedQuery("UsedCar.findAll", UsedCar.class);
        return query.getResultList();
    }

    // Method to query a UsedCar by reference number
    public UsedCar findByReferenceNumber(String referenceNumber) {
        TypedQuery<UsedCar> query = em.createNamedQuery("UsedCar.findByReferenceNumber", UsedCar.class);
        query.setParameter("referenceNumber", referenceNumber);
        return query.getSingleResult();
    }

    // Method to increase the number of cars in stock
    public void increaseCarNumber(String referenceNumber, int amount) {
        UsedCar car = findByReferenceNumber(referenceNumber);
        if (car != null) {
            car.setNumberOfCars(car.getNumberOfCars() + amount);
            em.merge(car); // update the entity
        }
    }

    // Method to reduce the number of cars in stock
    public void reduceCarNumber(String referenceNumber, int amount) {
        UsedCar car = findByReferenceNumber(referenceNumber);
        if (car != null && car.getNumberOfCars() >= amount) {
            car.setNumberOfCars(car.getNumberOfCars() - amount);
            em.merge(car); // update the entity
        } else {
            throw new IllegalArgumentException("Insufficient stock to reduce");
        }
    }
}

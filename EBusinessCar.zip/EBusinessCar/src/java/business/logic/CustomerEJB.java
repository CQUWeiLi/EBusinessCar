package business.logic;

import business.entities.Customer;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class CustomerEJB {

    @PersistenceContext(unitName = "CarPU")
    private EntityManager em;

    // Method to persist a new Customer
    public Customer createCustomer(Customer customer) {
        em.persist(customer);
        return customer;
    }

    // Method to merge/update an existing Customer
    public void mergeCustomer(Customer customer) {
        em.merge(customer);
    }

    // Method to find a Customer by name (using a named query)
    public List<Customer> findByName(String name) {
        TypedQuery<Customer> query = em.createNamedQuery("Customer.findByName", Customer.class);
        query.setParameter("name", name);
        return query.getResultList();
    }

    // Method to find a Customer by ID
    public Customer find(Long id) {
        return em.find(Customer.class, id);
    }

    // Method to find all Customers
    public List<Customer> findCustomers() {
        TypedQuery<Customer> query = em.createNamedQuery("Customer.findAll", Customer.class);
        return query.getResultList();
    }
}

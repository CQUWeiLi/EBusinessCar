package business.logic;

import business.entities.Car;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

import java.util.List;

@Stateless
public class CarEJB {

    @PersistenceContext(unitName = "CarPU")
    private EntityManager em;

    /**
     * Retrieves a list of all cars, including brand-new and used cars.
     *
     * @return List of all cars.
     */
    public List<Car> findAllCars() {
        TypedQuery<Car> query = em.createQuery("SELECT c FROM Car c", Car.class);
        return query.getResultList();
    }

    /**
     * Finds a specific car by its ID.
     *
     * @param id The ID of the car.
     * @return The car with the specified ID, or null if not found.
     */
    public Car findCarById(Long id) {
        return em.find(Car.class, id);
    }
    
    public void updateCarStock(Long carId, int newStock) {
        Car car = em.find(Car.class, carId);
        if (car != null) {
            car.setNumberOfCars(newStock);
            em.merge(car);
        }
    }
    
    
}

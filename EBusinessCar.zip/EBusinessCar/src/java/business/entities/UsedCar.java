package business.entities;

import jakarta.persistence.*;

@Entity
@NamedQueries({
        @NamedQuery(name = "UsedCar.findAll", query = "SELECT u FROM UsedCar u"),
        @NamedQuery(name = "UsedCar.findByReferenceNumber", query = "SELECT u FROM UsedCar u WHERE u.referenceNumber = :referenceNumber")
    })
public class UsedCar extends Car {
    private int odometer;
    private String regoNumber;
    private String regoExpiry;
    private String serviceHistory;
    private String vin;
    private String carHistory;

    // Constructors
    public UsedCar() {
    }

    // Getters and setters
    public int getOdometer() {
        return odometer;
    }

    public void setOdometer(int odometer) {
        this.odometer = odometer;
    }

    public String getRegoNumber() {
        return regoNumber;
    }

    public void setRegoNumber(String regoNumber) {
        this.regoNumber = regoNumber;
    }

    public String getRegoExpiry() {
        return regoExpiry;
    }

    public void setRegoExpiry(String regoExpiry) {
        this.regoExpiry = regoExpiry;
    }

    public String getServiceHistory() {
        return serviceHistory;
    }

    public void setServiceHistory(String serviceHistory) {
        this.serviceHistory = serviceHistory;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCarHistory() {
        return carHistory;
    }

    public void setCarHistory(String carHistory) {
        this.carHistory = carHistory;
    }
}
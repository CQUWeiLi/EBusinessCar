package business.entities;

import jakarta.persistence.*;

@Entity
@NamedQueries({
        @NamedQuery(name = "BrandNewCar.findAll", query = "SELECT b FROM BrandNewCar b"),
        @NamedQuery(name = "BrandNewCar.findByReferenceNumber", query = "SELECT b FROM BrandNewCar b WHERE b.referenceNumber = :referenceNumber")
    })
public class BrandNewCar extends Car {
    private String warranty;
    private String extendingWarranty;
    private String roadsideAssistancePackages;
    
    // Constructors
    public BrandNewCar() {
    }

    // Getters and setters
    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public String getExtendingWarranty() {
        return extendingWarranty;
    }

    public void setExtendingWarranty(String extendingWarranty) {
        this.extendingWarranty = extendingWarranty;
    }

    public String getRoadsideAssistancePackages() {
        return roadsideAssistancePackages;
    }

    public void setRoadsideAssistancePackages(String roadsideAssistancePackages) {
        this.roadsideAssistancePackages = roadsideAssistancePackages;
    }
}

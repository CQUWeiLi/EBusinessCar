package business.entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@NamedQueries({
    @NamedQuery(name = "CarOrder.findAll", query = "SELECT o FROM CarOrder o"),
    @NamedQuery(name = "CarOrder.findByOrderID", query = "SELECT o FROM CarOrder o WHERE o.id = :orderID")
})
public class CarOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double unitPrice;
    private int quantity;
    private LocalDateTime createdTime;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "car_id")
    private Car car;

    // Constructors
    public CarOrder() {
    }

    public CarOrder(double unitPrice, int quantity, LocalDateTime createdTime) {
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.createdTime = createdTime;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}

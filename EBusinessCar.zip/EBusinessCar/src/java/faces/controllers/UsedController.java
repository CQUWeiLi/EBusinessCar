package faces.controllers;

import business.logic.UsedEJB;
import business.entities.UsedCar;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.inject.Inject;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.util.List;

@Named
@RequestScoped
public class UsedController {

    private UsedCar usedCar = new UsedCar(); 
    private List<UsedCar> allUsedCars; 
    private String searchReferenceNumber; 

    @Inject
    private UsedEJB usedEJB; // Injecting the UsedEJB

    public String createUsedCar() {
        usedEJB.createUsedCar(usedCar);
        return "UsedConfirmation.xhtml";
    }

    public String searchByReferenceNumber() {
        try {
            usedCar = usedEJB.findByReferenceNumber(searchReferenceNumber);
            return "UsedSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("The car cannot be found, please check the reference number!"));
            return null;
        }
    }
    
    public String searchByReferenceNumber(String refNumber) {
        try {
            usedCar = usedEJB.findByReferenceNumber(refNumber);
            return "UsedSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("The car cannot be found, please check the reference number!"));
            return null;
        }
    }

    public UsedCar getUsedCar() {
        return usedCar;
    }
    public void setUsedCar(UsedCar usedCar) {
        this.usedCar = usedCar;
    }

    /*public List<UsedCar> getAllUsedCarsList() {
        return allUsedCars;
    }*/

    public List<UsedCar> getAllUsedCars() {
        
        return usedEJB.findAllUsedCars();
    }
    public void setAllUsedCars(List<UsedCar> allUsedCars) {
        this.allUsedCars = allUsedCars;
    }

    public String getSearchReferenceNumber() {
        return searchReferenceNumber;
    }
    public void setSearchReferenceNumber(String searchReferenceNumber) {
        this.searchReferenceNumber = searchReferenceNumber;
    }
}

package faces.controllers;

import business.logic.BrandNewEJB;
import business.entities.BrandNewCar;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import java.util.List;

@Named
@RequestScoped
public class BrandNewController {

    private BrandNewCar brandNewCar = new BrandNewCar();
    private String referenceNumber; 
    private List<BrandNewCar> allBrandNewCars;

    @Inject
    private BrandNewEJB brandNewEJB;

    public String createBrandNewCar() {
        brandNewEJB.createBrandNewCar(brandNewCar);
        return "BrandNewConfirmation.xhtml";
    }

    public String searchBrandNewCar() {
        try {
            brandNewCar = brandNewEJB.findByReferenceNumber(referenceNumber);
            return "BrandNewSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("The car cannot be found, please check the reference number!"));
            return null; 
        }
    }
    
    public String searchBrandNewCar(String refNumber) {
        try {
            brandNewCar = brandNewEJB.findByReferenceNumber(refNumber);
            return "BrandNewSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("The car cannot be found, please check the reference number!"));
            return null; 
        }
    }

    public BrandNewCar getBrandNewCar() {
        return brandNewCar;
    }
    public void setBrandNewCar(BrandNewCar brandNewCar) {
        this.brandNewCar = brandNewCar;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }
    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    /*public List<BrandNewCar> getAllBrandNewCarsList() {
        return allBrandNewCars;
    }*/

    public List<BrandNewCar> getAllBrandNewCars() {
        return brandNewEJB.findAllBrandNewCars();
       
    }
    public void setAllBrandNewCars(List<BrandNewCar> allBrandNewCars) {
        this.allBrandNewCars = allBrandNewCars;
    }
}

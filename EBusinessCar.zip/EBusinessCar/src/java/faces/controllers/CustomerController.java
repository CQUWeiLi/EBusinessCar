package faces.controllers;

import business.entities.CarOrder;
import business.entities.Customer;
import business.logic.CustomerEJB;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named
@RequestScoped
public class CustomerController {

    @EJB
    private CustomerEJB customerEJB;

    private Customer customer = new Customer();
    private List<Customer> allCustomersList;
    private String searchName;
    private List<Customer> searchResults;
    private List<CarOrder> ordersOfSearchedCustomers;
    
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String createCustomer() {
        customerEJB.createCustomer(customer);
        return "CustomerConfirmation.xhtml";
    }

    public List<Customer> getAllCustomers() {
        //Logger.getLogger(OrderController.class.getName()).info(" being called in getALLCustomers()");
        return customerEJB.findCustomers();
    }

    /*public List<Customer> getAllCustomersList() {
        //Logger.getLogger(OrderController.class.getName()).info(" being called in getAllCustomersList()");
        return customerEJB.findCustomers();
    }*/

    public String getSearchName() {
        return searchName;
    }
    public void setSearchName(String searchName) {
        this.searchName = searchName;
    }

    public List<Customer> getSearchResults() {
        //Logger.getLogger(OrderController.class.getName()).info(" being called in getSearchResults()");
        return searchResults;
    }

    public String searchCustomerByName() {
         //Logger.getLogger(CustomerController.class.getName()).info(" being called in searchCustomerByName()");
        try {
            searchResults = customerEJB.findByName(searchName);
            populateOrdersOfSearchedCustomers();
            if (searchResults.isEmpty()) {
                throw new Exception("Customer not found");
            }
            return "CustomerSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage("The customer cannnot be found, please check the customer name!"));
            return null; 
        }
    }
    
    public String searchCustomerByName(String name) {
        //Logger.getLogger(CustomerController.class.getName()).log(Level.INFO, " being called in searchCustomerByName(String name) the name:{0}", name);
        try {
            searchResults = customerEJB.findByName(name);
            populateOrdersOfSearchedCustomers();
            if (searchResults.isEmpty()) {
                throw new Exception("Customer not found");
            }
            return "CustomerSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage("The customer cannnot be found, please check the customer name!"));
            return null; 
        }
    }
    
    public List<CarOrder> getOrdersOfSearchedCustomers() {
        if (ordersOfSearchedCustomers == null) {
            populateOrdersOfSearchedCustomers();
        }
        return ordersOfSearchedCustomers;
    }

    private void populateOrdersOfSearchedCustomers() {
        ordersOfSearchedCustomers = new ArrayList<>();
        if (searchResults != null) {
            for (Customer customer : searchResults) {
                ordersOfSearchedCustomers.addAll(customer.getOrders());
            }
        }
    }
}

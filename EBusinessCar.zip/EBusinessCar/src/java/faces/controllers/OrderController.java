package faces.controllers;

import business.entities.Car;
import business.entities.Customer;
import business.entities.CarOrder;
import business.logic.CarEJB;
import business.logic.CustomerEJB;
import business.logic.OrderEJB;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.Serializable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
//import java.util.logging.Logger;

@Named
@SessionScoped
public class OrderController implements Serializable {

    @EJB
    private CarEJB carEJB;
    @EJB
    private CustomerEJB customerEJB;
    @EJB
    private OrderEJB orderEJB;

    private Long selectedCustomerId;
    private Long selectedCarId;
    private int quantity;
    private CarOrder order;
    private List<CarOrder> allOrdersList; 
    private Long orderId;
    private String customerName;
    private String referenceNumber;
    
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {    
        this.customerName = customerName;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }
    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }
    
    public Long getSelectedCustomerId() {
        return selectedCustomerId;
    }
    public void setSelectedCustomerId(Long selectedCustomerId) {
        this.selectedCustomerId = selectedCustomerId;
    }

    public Long getSelectedCarId() {
        return selectedCarId;
    }
    public void setSelectedCarId(Long selectedCarId) {
        this.selectedCarId = selectedCarId;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public CarOrder getOrder() {
        return order;
    }

    /*public List<CarOrder> getAllOrdersList() {
        allOrdersList = orderEJB.findAllOrders();
        return allOrdersList;
    }*/

    public List<Customer> getAllCustomers() {
        return customerEJB.findCustomers();
    }

    public List<Car> getAllCars() {
        return carEJB.findAllCars();
    }

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String createOrder() {
        Customer customer = customerEJB.find(selectedCustomerId);
        Car car = carEJB.findCarById(selectedCarId);
        if (customer == null || car == null) {
            throw new IllegalArgumentException("Customer or Car not found.");
        }
        if (car.getNumberOfCars() < quantity) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Not enough cars available for the order!", null));
            return null; 
        }
        order = new CarOrder();
        order.setCustomer(customer);
        order.setCar(car);
        order.setQuantity(quantity);
        order.setUnitPrice(car.getPrice());
        order.setCreatedTime(LocalDateTime.now());
        order = orderEJB.createOrder(order);
        carEJB.updateCarStock(selectedCarId, car.getNumberOfCars() - quantity);
        this.setCustomerName(order.getCustomer().getName());
        this.setReferenceNumber(order.getCar().getReferenceNumber());
        return "OrderConfirmation.xhtml";
    }

    public List<CarOrder> getAllOrders() {
        
        return orderEJB.findAllOrders(); 
    }
    
    public String formatCreatedTime(LocalDateTime createdTime) {
        if (createdTime == null) {
            return "";
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss - dd/MM/yyyy");
        return createdTime.format(formatter);
    }

    public String searchOrder() {
        try {
            order = orderEJB.findOrderById(orderId);
            if (order == null) {
                throw new Exception("Order not found");
            }
            this.setCustomerName(order.getCustomer().getName());
            this.setReferenceNumber(order.getCar().getReferenceNumber());
            return "OrderSearchResult.xhtml";
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage("The order cannnot be found, please check the order ID!"));
            return null; 
        }
    }

    public String deleteOrder(CarOrder carorder) {
        //Logger.getLogger(OrderController.class.getName()).info("Deleting order: " + carorder.getId());
        if (carorder == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Order not found.", null));
            return null;
        }
        Car car = carorder.getCar();
        carEJB.updateCarStock(car.getId(), car.getNumberOfCars() + carorder.getQuantity());
        orderEJB.deleteOrder(carorder);
        allOrdersList = orderEJB.findAllOrders();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Order deleted successfully.", null));
        return "OrderList.xhtml";
    }
}
